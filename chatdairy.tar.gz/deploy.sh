#!/bin/bash

# Configuration
VPS_USER="root"        # Replace with your VPS username
VPS_IP="your_vps_ip"   # Replace with your VPS IP address
REMOTE_DIR="/root/chatdairy" # Destination directory on VPS

echo "🚀 Starting deployment to $VPS_IP..."

# 1. Create remote directory
echo "📂 Creating remote directory..."
ssh $VPS_USER@$VPS_IP "mkdir -p $REMOTE_DIR"

# 2. Upload files using rsync (excludes node_modules and .git for speed)
echo "📤 Uploading files..."
rsync -avz --progress \
    --exclude 'node_modules' \
    --exclude '.git' \
    --exclude 'dist' \
    --exclude '.DS_Store' \
    . $VPS_USER@$VPS_IP:$REMOTE_DIR

# 3. Build and run on VPS
echo "🏗️  Building and starting services on VPS..."
ssh $VPS_USER@$VPS_IP "cd $REMOTE_DIR && docker compose up -d --build"

echo "✅ Deployment complete! Visit http://$VPS_IP:8080"
