import React, { createContext, useContext, useState, useEffect } from 'react';

const TRANSLATIONS = {
  'zh-TW': {
    'nav.write': '寫日記',
    'nav.calendar': '日曆',
    'nav.categories': '分類',
    'nav.profile': '個人',
    'nav.settings': '設置',
    'common.save': '保存',
    'common.cancel': '取消',
    'common.delete': '刪除',
    'common.edit': '編輯',
  },
  'zh-CN': {
    'nav.write': '写日记',
    'nav.calendar': '日历',
    'nav.categories': '分类',
    'nav.profile': '个人',
    'nav.settings': '设置',
    'common.save': '保存',
    'common.cancel': '取消',
    'common.delete': '删除',
    'common.edit': '编辑',
  },
  'en-US': {
    'nav.write': 'Write',
    'nav.calendar': 'Calendar',
    'nav.categories': 'Categories',
    'nav.profile': 'Profile',
    'nav.settings': 'Settings',
    'common.save': 'Save',
    'common.cancel': 'Cancel',
    'common.delete': 'Delete',
    'common.edit': 'Edit',
  },
  'ja-JP': {
    'nav.write': '書く',
    'nav.calendar': 'カレンダー',
    'nav.categories': 'カテゴリー',
    'nav.profile': 'プロフィール',
    'nav.settings': '設定',
    'common.save': '保存',
    'common.cancel': 'キャンセル',
    'common.delete': '削除',
    'common.edit': '編集',
  }
};

const DEFAULT_THEME = {
  language: 'zh-TW',
  primaryColor: '#4A453E',
  backgroundColor: '#FDFBF7',
  chatBgImage: null,
  bubbleCss: '',
};

const ThemeContext = createContext({
  theme: DEFAULT_THEME,
  updateTheme: () => {},
  resetTheme: () => {},
  t: (key) => key,
});

export function ThemeProvider({ children }) {
  const [theme, setTheme] = useState(() => {
    try {
      const saved = localStorage.getItem('app_theme');
      return saved ? { ...DEFAULT_THEME, ...JSON.parse(saved) } : DEFAULT_THEME;
    } catch (e) {
      return DEFAULT_THEME;
    }
  });

  useEffect(() => {
    localStorage.setItem('app_theme', JSON.stringify(theme));
    
    // Apply CSS variables
    const root = document.documentElement;
    root.style.setProperty('--color-cream-900', theme.primaryColor);
    root.style.setProperty('--color-diary-bg', theme.backgroundColor);
    
    // Apply Bubble CSS
    let styleTag = document.getElementById('custom-bubble-css');
    if (!styleTag) {
      styleTag = document.createElement('style');
      styleTag.id = 'custom-bubble-css';
      document.head.appendChild(styleTag);
    }
    styleTag.textContent = theme.bubbleCss || '';

  }, [theme]);

  const updateTheme = (updates) => {
    setTheme(prev => ({ ...prev, ...updates }));
  };

  const resetTheme = () => {
    setTheme(DEFAULT_THEME);
  };

  const t = (key) => {
    const lang = theme.language || 'zh-TW';
    return TRANSLATIONS[lang]?.[key] || TRANSLATIONS['zh-TW']?.[key] || key;
  };

  return (
    <ThemeContext.Provider value={{ theme, updateTheme, resetTheme, t }}>
      {children}
    </ThemeContext.Provider>
  );
}

export const useTheme = () => useContext(ThemeContext);
